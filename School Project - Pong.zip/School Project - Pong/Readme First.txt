Hi!

This is a school project, my first one. I'm a swedish "soon-to-be" game developer, and I wonder, is this a good start
in the career in this kind of work? I've been studying C# since September 2018-present (December 2018) and this
was our first assignment to code.

Time to code: 16+h (4hours per week in 4 weeks, plus some coding at home)
Assignment: Remake the pong game with your own touch, in this case 4 player splitscreen.
Engine: Monogame
Language: C#
Art: Rasweed (GitHub)
Code: Me

You can find the source code and graphics to the first version of this game on GitHub.
https://github.com/lbspong


If you have read this far in this document, please leave a comment on what I can improve in the game, any ideas that could be
fun to have in the game.

Thank you, and please, no hate. If there's anything bad with it, leave a constructive comment and no hate. This itch.io community
will be so much nicer with people who help eachother out with ideas, improvements, and relative things.

Best Regards